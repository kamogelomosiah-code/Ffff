
import React, { useState } from 'react';
import { Outlet, useNavigate, useSearchParams } from 'react-router-dom';
import { useStore } from '../../context/StoreContext';
import { ShoppingCart, Search, Menu, User, X, ShoppingBag, LayoutDashboard } from '../common/Icons';
import { CURRENCY } from '../../constants';

const StorefrontLayout: React.FC = () => {
  const { config, cart, removeFromCart, updateCartItemQuantity } = useStore();
  const [isCartOpen, setIsCartOpen] = useState(false);
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const currentSearchTerm = searchParams.get('searchTerm') || '';
  const [searchInput, setSearchInput] = useState(currentSearchTerm);

  const cartTotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);

  const handleCheckout = () => {
    setIsCartOpen(false);
    navigate('/store/checkout');
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      navigate(`/store?searchTerm=${encodeURIComponent(searchInput)}`);
    } else {
      searchParams.delete('searchTerm');
      setSearchParams(searchParams);
      navigate('/store');
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col selection:bg-gray-100">
      {/* Premium Notification Bar */}
      <div className="bg-neutral-50 text-neutral-600 text-[11px] uppercase tracking-[0.1em] py-2 text-center border-b border-gray-100 px-4 font-medium">
        Curated Selection • Fast Local Delivery • Verified Age Only
      </div>

      {/* Boutique Header */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-gray-100 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
            {/* Left Nav */}
            <div className="flex items-center gap-8">
                <button className="md:hidden text-gray-900" aria-label="Menu"><Menu size={20} /></button>
                <div 
                  onClick={() => { navigate('/store'); setSearchInput(''); }} 
                  className="cursor-pointer group flex items-center gap-3"
                >
                    <div className="w-9 h-9 flex items-center justify-center text-white font-serif italic text-xl transition-transform group-hover:scale-105" style={{ backgroundColor: config.primaryColor }}>S</div>
                    <span className="font-serif font-semibold text-2xl tracking-tight hidden sm:block">{config.storeName}</span>
                </div>
                <nav className="hidden md:flex items-center gap-6 text-[13px] font-medium uppercase tracking-wider text-neutral-500">
                    <a href="#" className="hover:text-black transition-colors">Spirits</a>
                    <a href="#" className="hover:text-black transition-colors">Wine</a>
                    <a href="#" className="hover:text-black transition-colors">Beer</a>
                </nav>
            </div>

            {/* Right Actions */}
            <div className="flex items-center gap-1 sm:gap-2">
                <form onSubmit={handleSearchSubmit} className="hidden lg:flex items-center relative mr-4">
                    <input 
                        type="text" 
                        placeholder="Search our cellar..."
                        className="w-48 bg-transparent border-b border-transparent hover:border-neutral-200 focus:border-black focus:w-64 py-1 pr-8 text-sm transition-all outline-none"
                        value={searchInput}
                        onChange={(e) => setSearchInput(e.target.value)}
                        aria-label="Search"
                    />
                    <Search size={16} className="absolute right-2 text-neutral-400" />
                </form>
                
                {/* Admin Switch Button */}
                <button 
                  onClick={() => navigate('/dashboard')}
                  className="p-2.5 text-neutral-400 hover:text-black transition-colors rounded-full flex items-center gap-2 group"
                  title="Switch to Staff Portal"
                >
                    <LayoutDashboard size={20} />
                    <span className="text-[10px] font-bold uppercase tracking-widest hidden xl:block opacity-0 group-hover:opacity-100 transition-opacity">Staff Portal</span>
                </button>

                <button className="p-2.5 text-neutral-600 hover:text-black transition-colors rounded-full" aria-label="Account">
                    <User size={20} />
                </button>
                <button 
                    onClick={() => setIsCartOpen(true)}
                    className="p-2.5 text-neutral-600 hover:text-black transition-colors rounded-full relative group"
                    aria-label="Cart"
                >
                    <ShoppingCart size={20} />
                    {cart.length > 0 && (
                        <span className="absolute top-1 right-1 w-4 h-4 bg-black text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                            {cart.length}
                        </span>
                    )}
                </button>
            </div>
        </div>
      </header>

      <main className="flex-1">
        <Outlet />
      </main>

      {/* Minimalist Footer */}
      <footer className="bg-white border-t border-gray-100 py-16 mt-auto">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-12 gap-12">
            <div className="md:col-span-4">
                <h3 className="font-serif font-bold text-2xl mb-4">{config.storeName}</h3>
                <p className="text-sm text-neutral-500 leading-relaxed max-w-xs">
                    Crafting a premium spirits experience for the modern connoisseur. Quality over quantity, always.
                </p>
            </div>
            <div className="md:col-span-2">
                <h4 className="text-[12px] font-bold uppercase tracking-widest text-black mb-6">Collections</h4>
                <ul className="space-y-3 text-sm text-neutral-500">
                    <li><a href="#" className="hover:text-black transition-colors">Single Malts</a></li>
                    <li><a href="#" className="hover:text-black transition-colors">Craft Gins</a></li>
                    <li><a href="#" className="hover:text-black transition-colors">Rare Vintages</a></li>
                    <li><a href="#" className="hover:text-black transition-colors">Small Batch Bourbon</a></li>
                </ul>
            </div>
            <div className="md:col-span-2">
                <h4 className="text-[12px] font-bold uppercase tracking-widest text-black mb-6">Experience</h4>
                <ul className="space-y-3 text-sm text-neutral-500">
                    <li><a href="#" className="hover:text-black transition-colors">The Boutique</a></li>
                    <li><a href="#" className="hover:text-black transition-colors">Shipping & Returns</a></li>
                    <li><a href="#" className="hover:text-black transition-colors">Gifting</a></li>
                    <li><a href="#" className="hover:text-black transition-colors">Privacy</a></li>
                </ul>
            </div>
            <div className="md:col-span-4">
                <h4 className="text-[12px] font-bold uppercase tracking-widest text-black mb-6">Newsletter</h4>
                <p className="text-sm text-neutral-500 mb-4">Be the first to know about rare arrivals.</p>
                <div className="flex gap-2">
                    <input type="email" placeholder="Your email" className="flex-1 bg-neutral-50 border border-neutral-200 px-4 py-2 text-sm focus:outline-none focus:border-black" />
                    <button className="px-6 py-2 bg-black text-white text-xs font-bold uppercase tracking-tighter hover:bg-neutral-800 transition-colors">Join</button>
                </div>
            </div>
        </div>
        <div className="max-w-7xl mx-auto px-6 mt-20 pt-8 border-t border-neutral-100 flex flex-col md:flex-row justify-between items-center gap-4 text-[11px] text-neutral-400 uppercase tracking-widest">
            <p>© 2024 {config.storeName}</p>
            <p>Please drink responsibly • Age 21+</p>
            <div className="flex gap-4">
                <a href="#" className="hover:text-black">Instagram</a>
                <a href="#" className="hover:text-black">Twitter</a>
            </div>
        </div>
      </footer>

      {/* Cart Slider */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden" role="dialog" aria-modal="true">
            <div className="absolute inset-0 bg-neutral-900/40 backdrop-blur-sm transition-opacity" onClick={() => setIsCartOpen(false)}></div>
            <div className="absolute right-0 top-0 bottom-0 w-full max-w-sm bg-white shadow-2xl flex flex-col">
                <div className="p-6 border-b border-neutral-100 flex items-center justify-between">
                    <h2 className="text-sm font-bold uppercase tracking-widest">Your Selection</h2>
                    <button onClick={() => setIsCartOpen(false)} className="p-2 hover:bg-neutral-50 rounded-full transition-colors"><X size={18} /></button>
                </div>

                <div className="flex-1 overflow-y-auto p-6 space-y-8">
                    {cart.length === 0 ? (
                        <div className="flex flex-col items-center justify-center h-full text-center py-20">
                            <ShoppingBag size={40} className="mb-4 text-neutral-200" />
                            <p className="text-neutral-500 text-sm">Your basket is empty.</p>
                            <button onClick={() => setIsCartOpen(false)} className="mt-6 text-xs font-bold uppercase underline tracking-widest">Start Browsing</button>
                        </div>
                    ) : (
                        cart.map((item, idx) => (
                            <div key={`${item.productId}-${idx}`} className="flex gap-4 animate-in fade-in slide-in-from-right-4 duration-300">
                                <div className="w-20 h-24 bg-neutral-50 rounded overflow-hidden flex-shrink-0 border border-neutral-100 p-2">
                                    <img src={item.image} alt={item.name} className="w-full h-full object-contain mix-blend-multiply" />
                                </div>
                                <div className="flex-1 flex flex-col justify-between">
                                    <div>
                                        <h4 className="text-[13px] font-semibold text-black leading-tight mb-1">{item.name}</h4>
                                        <p className="text-xs text-neutral-500">{CURRENCY}{item.price.toFixed(2)}</p>
                                    </div>
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-3 border border-neutral-100 px-2 py-1">
                                            <button onClick={() => updateCartItemQuantity(item.productId, item.quantity - 1)} className="text-neutral-400 hover:text-black">-</button>
                                            <span className="text-xs font-medium min-w-[12px] text-center">{item.quantity}</span>
                                            <button onClick={() => updateCartItemQuantity(item.productId, item.quantity + 1)} className="text-neutral-400 hover:text-black">+</button>
                                        </div>
                                        <button onClick={() => removeFromCart(item.productId)} className="text-[10px] text-neutral-400 uppercase font-bold hover:text-red-500 transition-colors">Remove</button>
                                    </div>
                                </div>
                            </div>
                        ))
                    )}
                </div>

                {cart.length > 0 && (
                    <div className="p-6 border-t border-neutral-100">
                        <div className="flex justify-between mb-2 text-sm">
                            <span className="text-neutral-500">Subtotal</span>
                            <span className="font-bold">{CURRENCY}{cartTotal.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between mb-8 text-[11px] uppercase tracking-widest">
                            <span className="text-neutral-400">Shipping</span>
                            <span className="text-neutral-400">Calculated at Checkout</span>
                        </div>
                        <button 
                            className="w-full py-4 bg-black text-white text-[12px] font-bold uppercase tracking-widest hover:bg-neutral-800 transition-all active:scale-95"
                            onClick={handleCheckout}
                        >
                            Checkout • {CURRENCY}{cartTotal.toFixed(2)}
                        </button>
                    </div>
                )}
            </div>
        </div>
      )}
    </div>
  );
};

export default StorefrontLayout;
