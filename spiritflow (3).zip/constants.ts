
import { Product, Order, StoreConfig, PrimaryColorPreset } from './types';

export const CURRENCY = 'R';

export const INITIAL_CONFIG: StoreConfig = {
  storeName: "SpiritFlow Boutique",
  primaryColor: PrimaryColorPreset.Navy,
  layout: 'grid',
  heroImage: "https://images.unsplash.com/photo-1569937756447-e24e5256e409?auto=format&fit=crop&q=80&w=2000",
  heroHeadline: "Purveyors of Fine Spirits",
  heroSubheadline: "Exclusive collections delivered to your door in under 60 minutes.",
  contactEmail: "concierge@spiritflow.com",
  contactPhone: "+27 (0) 10 123 4567"
};

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 1,
    name: "Hibiki Japanese Harmony",
    category: "Spirits",
    subcategory: "Whisky",
    price: 2450.00,
    stock: 12,
    sku: "JP-WHI-001",
    image: "https://images.unsplash.com/photo-1527281400683-1aae777175f8?auto=format&fit=crop&q=80&w=1000",
    description: "A meticulous blend of the finest select whiskies from the House of Suntory Osaka. Notes of honey, candied orange peel, and white chocolate.",
    abv: 43.0,
    volume: "750ml",
    featured: true
  },
  {
    id: 2,
    name: "Don Julio 1942",
    category: "Spirits",
    subcategory: "Tequila",
    price: 3800.00,
    stock: 8,
    sku: "TEQ-1942",
    image: "https://images.unsplash.com/photo-1516535794938-606387ce56dc?auto=format&fit=crop&q=80&w=1000",
    description: "Small batch añejo tequila aged for a minimum of two and a half years. Rich caramel and chocolate notes with a warm oak finish.",
    abv: 38,
    volume: "750ml",
    featured: true
  },
  {
    id: 3,
    name: "Hendrick's Flora Adora",
    category: "Spirits",
    subcategory: "Gin",
    price: 549.00,
    stock: 24,
    sku: "GIN-HEN-FLO",
    image: "https://images.unsplash.com/photo-1606758671758-305b9b777a41?auto=format&fit=crop&q=80&w=1000",
    description: "A limited release from the Cabinet of Curiosities. Infused with a bouquet of enticing flowers and fresh herbal character.",
    abv: 43.4,
    volume: "750ml",
    featured: true
  },
  {
    id: 4,
    name: "Moët & Chandon Imperial",
    category: "Wine",
    subcategory: "Champagne",
    price: 799.00,
    stock: 40,
    sku: "CHAM-MOET",
    image: "https://images.unsplash.com/photo-1598155523122-38423bb4d6cf?auto=format&fit=crop&q=80&w=1000",
    description: "The vibrant intensity of green apple and citrus fruit, the freshness of mineral nuances and white flowers.",
    abv: 12.0,
    volume: "750ml",
    featured: true
  },
  {
    id: 5,
    name: "Stellenbosch Cabernet",
    category: "Wine",
    subcategory: "Red",
    price: 325.00,
    stock: 30,
    sku: "WIN-STE-CAB",
    image: "https://images.unsplash.com/photo-1506377247377-2a5b3b417ebb?auto=format&fit=crop&q=80&w=1000",
    description: "Full-bodied with aromas of blackcurrant, dark chocolate, and tobacco box. Aged 18 months in French oak.",
    abv: 14.5,
    volume: "750ml",
    featured: false
  }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: "ORD-8821",
    customerName: "James St. Patrick",
    customerEmail: "james@truth.com",
    customerPhone: "082 555 0192",
    date: "2023-11-15T19:30:00",
    status: "out-for-delivery",
    total: 2450.00,
    deliveryAddress: "Penthouse Suite, The Leonardo, Sandton, 2196",
    items: [
      { 
        productId: 1, 
        name: "Hibiki Japanese Harmony", 
        price: 2450.00, 
        quantity: 1, 
        image: "https://images.unsplash.com/photo-1527281400683-1aae777175f8?auto=format&fit=crop&q=80&w=1000" 
      }
    ]
  },
  {
    id: "ORD-8820",
    customerName: "Sarah Cameron",
    customerEmail: "sarah@obx.com",
    customerPhone: "071 555 0341",
    date: "2023-11-15T14:15:00",
    status: "delivered",
    total: 1598.00,
    deliveryAddress: "12 Clifton 4th Beach, Cape Town, 8001",
    items: [
      { 
        productId: 4, 
        name: "Moët & Chandon Imperial", 
        price: 799.00, 
        quantity: 2, 
        image: "https://images.unsplash.com/photo-1598155523122-38423bb4d6cf?auto=format&fit=crop&q=80&w=1000" 
      }
    ]
  }
];
