import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useStore } from '../../context/StoreContext';
import { ShoppingCart, Plus, Check, ArrowUpRight } from '../common/Icons';
import { CURRENCY } from '../../constants';

const StoreHome: React.FC = () => {
  const { config, products, addToCart, cart } = useStore();
  const [activeCategory, setActiveCategory] = useState('All');
  const navigate = useNavigate();
  const location = useLocation();
  const [addedToCartFeedback, setAddedToCartFeedback] = useState<Record<number, boolean>>({});

  const categories = ['All', ...Array.from(new Set(products.map(p => p.category)))];

  const getFilteredAndSearchedProducts = () => {
    const queryParams = new URLSearchParams(location.search);
    const searchTerm = queryParams.get('searchTerm')?.toLowerCase() || '';
    return products.filter(p => {
      const matchesCategory = activeCategory === 'All' || p.category === activeCategory;
      const matchesSearch = searchTerm === '' || p.name.toLowerCase().includes(searchTerm);
      return matchesCategory && matchesSearch;
    });
  };

  const filteredProducts = getFilteredAndSearchedProducts();

  const handleAddToCartClick = (product: any) => {
    addToCart(product, 1);
    setAddedToCartFeedback(prev => ({ ...prev, [product.id]: true }));
    setTimeout(() => {
      setAddedToCartFeedback(prev => ({ ...prev, [product.id]: false }));
    }, 2000);
  };

  const isInCart = (id: number) => cart.some(item => item.productId === id);

  return (
    <div className="animate-in fade-in duration-700">
      {/* Editorial Hero */}
      <section className="relative h-[80vh] flex items-center bg-[#FDFDFD] overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-1/2 hidden lg:block">
            <img src={config.heroImage} alt="Featured" className="w-full h-full object-cover grayscale-[0.2]" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#FDFDFD] to-transparent"></div>
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-6 w-full">
            <div className="max-w-2xl">
                <span className="text-[11px] font-bold uppercase tracking-[0.4em] text-neutral-400 mb-6 block">Est. 2024</span>
                <h1 className="font-serif text-6xl md:text-8xl font-medium mb-8 leading-[1.1] tracking-tighter">
                   Elevated <br/>Selection.
                </h1>
                <p className="text-lg md:text-xl text-neutral-500 mb-10 max-w-md leading-relaxed">
                    A curated boutique for the discerning palate. Discover rare spirits and fine vintages delivered with care.
                </p>
                <div className="flex items-center gap-6">
                    <button 
                        onClick={() => document.getElementById('shop-section')?.scrollIntoView({ behavior: 'smooth' })}
                        className="px-10 py-5 bg-black text-white text-xs font-bold uppercase tracking-widest hover:bg-neutral-800 transition-all shadow-xl"
                    >
                        Explore Cellar
                    </button>
                    <a href="#" className="group flex items-center gap-2 text-xs font-bold uppercase tracking-widest border-b border-black pb-1">
                        New Arrivals <ArrowUpRight size={14} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                    </a>
                </div>
            </div>
        </div>
      </section>

      {/* Modern Filter & Grid */}
      <section id="shop-section" className="max-w-7xl mx-auto px-6 py-24">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-16 border-b border-neutral-100 pb-8">
            <div>
                <h2 className="font-serif text-4xl font-medium mb-2">The Collection</h2>
                <p className="text-neutral-400 text-sm">Showing {filteredProducts.length} unique expressions</p>
            </div>
            <div className="flex gap-8 text-[12px] font-bold uppercase tracking-widest overflow-x-auto pb-2 scrollbar-hide">
                {categories.map(cat => (
                    <button
                        key={cat}
                        onClick={() => setActiveCategory(cat)}
                        className={`transition-all whitespace-nowrap ${
                            activeCategory === cat ? 'text-black' : 'text-neutral-300 hover:text-neutral-500'
                        }`}
                    >
                        {cat}
                        {activeCategory === cat && <div className="h-0.5 w-full bg-black mt-2"></div>}
                    </button>
                ))}
            </div>
        </div>

        <div className={`grid gap-x-8 gap-y-16 ${config.layout === 'grid' ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' : 'grid-cols-1'}`}>
            {filteredProducts.map(product => (
                <div 
                    key={product.id} 
                    className={`group flex flex-col animate-in fade-in slide-in-from-bottom-4 duration-500`}
                >
                    <div 
                        onClick={() => navigate(`/product/${product.id}`)}
                        className="aspect-[4/5] bg-neutral-50 p-10 flex items-center justify-center relative overflow-hidden cursor-pointer group-hover:bg-neutral-100 transition-colors border border-neutral-100"
                    >
                        <img 
                            src={product.image} 
                            alt={product.name} 
                            className="w-full h-full object-contain mix-blend-multiply transition-transform duration-700 group-hover:scale-105" 
                        />
                        {/* Quick Add Overlay */}
                        <div className="absolute inset-x-0 bottom-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                             <button 
                                onClick={(e) => { e.stopPropagation(); handleAddToCartClick(product); }}
                                className="w-full py-3 bg-white/90 backdrop-blur shadow-sm text-[10px] font-bold uppercase tracking-widest hover:bg-black hover:text-white transition-all"
                             >
                                {addedToCartFeedback[product.id] ? 'In Basket' : 'Quick Add'}
                             </button>
                        </div>
                    </div>
                    
                    <div className="mt-6 flex flex-col gap-1">
                        <div className="flex justify-between items-start">
                            <h3 
                                onClick={() => navigate(`/product/${product.id}`)}
                                className="text-[14px] font-semibold text-black leading-tight cursor-pointer hover:underline underline-offset-4"
                            >
                                {product.name}
                            </h3>
                            <span className="text-[14px] font-medium text-neutral-500">{CURRENCY}{product.price.toFixed(2)}</span>
                        </div>
                        <p className="text-[12px] text-neutral-400 font-medium uppercase tracking-wider">{product.volume} • {product.category}</p>
                    </div>
                </div>
            ))}
        </div>
      </section>

      {/* Editorial Teasers */}
      <section className="grid md:grid-cols-2">
            <div className="relative aspect-square overflow-hidden group cursor-pointer">
                <img src="https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&q=80&w=1200" className="w-full h-full object-cover grayscale transition-transform duration-[2s] group-hover:scale-110" alt="Wine" />
                <div className="absolute inset-0 bg-black/30 flex flex-col justify-center items-center text-white p-12">
                    <span className="text-[10px] font-bold uppercase tracking-[0.5em] mb-4">Discovery</span>
                    <h3 className="font-serif text-4xl mb-6">The Rare Reds</h3>
                    <button className="px-8 py-3 border border-white text-[10px] font-bold uppercase tracking-widest hover:bg-white hover:text-black transition-all">Shop Wine</button>
                </div>
            </div>
            <div className="relative aspect-square overflow-hidden group cursor-pointer">
                <img src="https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&q=80&w=1200" className="w-full h-full object-cover grayscale transition-transform duration-[2s] group-hover:scale-110" alt="Spirits" />
                <div className="absolute inset-0 bg-neutral-900/50 flex flex-col justify-center items-center text-white p-12">
                    <span className="text-[10px] font-bold uppercase tracking-[0.5em] mb-4">Heritage</span>
                    <h3 className="font-serif text-4xl mb-6">Cask Strength</h3>
                    <button className="px-8 py-3 border border-white text-[10px] font-bold uppercase tracking-widest hover:bg-white hover:text-black transition-all">Shop Spirits</button>
                </div>
            </div>
      </section>
    </div>
  );
};

export default StoreHome;