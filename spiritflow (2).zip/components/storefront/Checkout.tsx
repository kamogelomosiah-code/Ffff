
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../../context/StoreContext';
/* Added missing Search icon to the imports */
import { Check, CreditCard, Lock, MapPin, ChevronRight, Plus, Trash2, Box, Truck, Search } from '../common/Icons';
import { CURRENCY } from '../../constants';

const Checkout: React.FC = () => {
  const navigate = useNavigate();
  const { cart, config, checkout } = useStore();
  
  const [step, setStep] = useState<1 | 2>(1);
  const [loading, setLoading] = useState(false);
  const [mapPinned, setMapPinned] = useState(false);

  // Form State
  const [contact, setContact] = useState({
    email: '',
    phone: '',
    firstName: '',
    lastName: '',
    address: '',
    city: '',
    state: '',
    zip: '',
    lat: -26.2041, // Default to Johannesburg coords as example
    lng: 28.0473
  });

  // Stripe-style Payment State
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'apple_pay'>('card');
  const [cardDetails, setCardDetails] = useState({
    number: '',
    expiry: '',
    cvc: '',
    zip: ''
  });

  const subtotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const shipping = subtotal > 500 ? 0 : 45; // Adjusted for ZAR context
  const tax = subtotal * 0.15; // 15% VAT
  const total = subtotal + shipping + tax;

  const handleContactChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setContact({ ...contact, [e.target.name]: e.target.value });
  };

  const handleCardChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let { name, value } = e.target;
    if (name === 'number') value = value.replace(/\D/g, '').replace(/(.{4})/g, '$1 ').trim();
    if (name === 'expiry') value = value.replace(/\D/g, '').replace(/^(\d{2})(\d{0,2})/, '$1/$2').trim();
    if (name === 'cvc') value = value.replace(/\D/g, '').slice(0, 4);
    setCardDetails({ ...cardDetails, [name]: value });
  };

  const handlePlaceOrder = () => {
    setLoading(true);
    setTimeout(() => {
      const orderId = checkout({
        name: `${contact.firstName} ${contact.lastName}`,
        email: contact.email,
        phone: contact.phone,
        address: contact.address || "Pinned Map Location"
      });
      setLoading(false);
      navigate(`/order-confirmation/${orderId}`);
    }, 2500);
  };

  const handlePinLocation = () => {
    setLoading(true);
    // Simulate getting current location
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setContact(prev => ({ ...prev, lat: pos.coords.latitude, lng: pos.coords.longitude }));
        setMapPinned(true);
        setLoading(false);
      },
      () => {
        setMapPinned(true); // Fallback to mock pin
        setLoading(false);
      }
    );
  };

  if (cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-6 py-32 text-center">
        <div className="w-20 h-20 bg-neutral-50 rounded-full flex items-center justify-center mx-auto mb-6 border border-neutral-100">
            <Check size={32} className="text-neutral-300" />
        </div>
        <h2 className="font-serif text-3xl font-medium mb-3">Your selection is empty</h2>
        <p className="text-neutral-500 mb-8 max-w-sm mx-auto">Discover our curated collection and add your favorite expressions to the basket.</p>
        <button 
          onClick={() => navigate('/')}
          className="px-10 py-4 bg-black text-white text-[11px] font-bold uppercase tracking-[0.2em] transition-all hover:bg-neutral-800"
        >
          Return to Cellar
        </button>
      </div>
    );
  }

  return (
    <div className="bg-white min-h-screen py-20 selection:bg-neutral-100">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-16">
        
        {/* Left: Checkout Flow */}
        <div className="lg:col-span-7 space-y-12">
            
            {/* Step 1: Delivery Details */}
            <section className={step === 2 ? 'opacity-40 grayscale pointer-events-none' : ''}>
                <div className="flex items-center justify-between mb-8">
                    <h2 className="font-serif text-3xl font-medium flex items-center gap-4">
                        <span className="text-xs font-bold w-7 h-7 bg-black text-white rounded-full flex items-center justify-center font-sans tracking-tighter">01</span>
                        Delivery Details
                    </h2>
                    {step === 2 && (
                        <button onClick={() => setStep(1)} className="text-[10px] font-bold uppercase tracking-widest underline decoration-neutral-200 underline-offset-8">Edit</button>
                    )}
                </div>

                <div className="space-y-10">
                    <div className="grid grid-cols-2 gap-6">
                        <div className="col-span-2 group">
                            <label className="text-[10px] font-bold uppercase tracking-widest text-neutral-400 mb-2 block transition-colors group-focus-within:text-black">Contact Email</label>
                            <input name="email" value={contact.email} onChange={handleContactChange} type="email" placeholder="connoisseur@example.com" className="w-full bg-transparent border-b border-neutral-200 py-3 text-sm outline-none focus:border-black transition-colors" />
                        </div>
                        <div className="group">
                            <label className="text-[10px] font-bold uppercase tracking-widest text-neutral-400 mb-2 block">First Name</label>
                            <input name="firstName" value={contact.firstName} onChange={handleContactChange} className="w-full bg-transparent border-b border-neutral-200 py-3 text-sm outline-none focus:border-black transition-colors" />
                        </div>
                        <div className="group">
                            <label className="text-[10px] font-bold uppercase tracking-widest text-neutral-400 mb-2 block">Last Name</label>
                            <input name="lastName" value={contact.lastName} onChange={handleContactChange} className="w-full bg-transparent border-b border-neutral-200 py-3 text-sm outline-none focus:border-black transition-colors" />
                        </div>
                    </div>

                    {/* Google Maps Integration UI */}
                    <div className="space-y-4">
                        <label className="text-[10px] font-bold uppercase tracking-widest text-neutral-400 block">Precise Delivery Location</label>
                        <div className="relative w-full h-[350px] bg-neutral-100 border border-neutral-200 overflow-hidden group">
                            {/* Mock Google Maps Interface */}
                            <div className="absolute inset-0 grayscale opacity-80" style={{ backgroundImage: 'url("https://www.google.com/maps/vt/pb=!1m4!1m3!1i14!2i9025!3i10543!2m3!1e0!2sm!3i600123456!3m17!2sen!3sUS!5e18!12m4!1e68!2m2!1sset!2sRoadmap!12m3!1e37!2m1!1ssmartmaps!12m4!1e26!2m2!1sstyles!2zY29sb3I6MHhmNWY1ZjUsaGlkZTp0cnVlLC4uLg!4e0!5m1!5f2!23i1301875")', backgroundSize: 'cover' }}></div>
                            <div className="absolute inset-0 flex items-center justify-center">
                                <div className={`relative transition-transform duration-500 ${mapPinned ? 'scale-110' : 'animate-bounce'}`}>
                                    <MapPin size={40} className={mapPinned ? 'text-black fill-white' : 'text-neutral-400'} />
                                    <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-3 h-1 bg-black/20 rounded-full blur-sm"></div>
                                </div>
                            </div>
                            <div className="absolute top-4 left-4 right-4 flex gap-2">
                                <div className="flex-1 relative">
                                    <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
                                    <input placeholder="Search address or pin location..." className="w-full pl-10 pr-4 py-2.5 bg-white border border-neutral-200 text-xs shadow-sm focus:outline-none" />
                                </div>
                            </div>
                            <button 
                                onClick={handlePinLocation}
                                className="absolute bottom-6 left-1/2 -translate-x-1/2 bg-black text-white px-6 py-2.5 text-[10px] font-bold uppercase tracking-widest shadow-xl transition-all hover:bg-neutral-800"
                            >
                                {mapPinned ? 'Location Pinned' : 'Confirm Location'}
                            </button>
                        </div>
                        {mapPinned && (
                            <div className="flex items-center gap-2 text-[11px] text-green-600 font-bold uppercase tracking-wider animate-in fade-in duration-500">
                                <Check size={14} /> Coordinates captured: {contact.lat.toFixed(4)}, {contact.lng.toFixed(4)}
                            </div>
                        )}
                    </div>

                    {step === 1 && (
                        <button 
                            onClick={() => setStep(2)}
                            className="w-full py-5 bg-black text-white text-[11px] font-bold uppercase tracking-[0.2em] shadow-lg hover:bg-neutral-800 transition-all"
                        >
                            Continue to Payment
                        </button>
                    )}
                </div>
            </section>

            {/* Step 2: Payment Gateway (Stripe Inspired) */}
            <section className={step === 1 ? 'opacity-30 pointer-events-none' : 'animate-in fade-in duration-700'}>
                <div className="flex items-center justify-between mb-8">
                    <h2 className="font-serif text-3xl font-medium flex items-center gap-4">
                        <span className="text-xs font-bold w-7 h-7 bg-black text-white rounded-full flex items-center justify-center font-sans tracking-tighter">02</span>
                        Payment
                    </h2>
                </div>

                <div className="bg-[#F6F9FC] p-8 rounded-xl border border-[#E6EBF1] space-y-8">
                    <div className="flex items-center gap-4 mb-2">
                        <button 
                            onClick={() => setPaymentMethod('card')}
                            className={`flex-1 py-3 px-4 flex items-center justify-center gap-2 text-xs font-bold uppercase tracking-wider border transition-all ${paymentMethod === 'card' ? 'bg-white border-neutral-300 shadow-sm' : 'border-transparent text-neutral-400'}`}
                        >
                            <CreditCard size={14} /> Card
                        </button>
                        <button 
                            onClick={() => setPaymentMethod('apple_pay')}
                            className={`flex-1 py-3 px-4 flex items-center justify-center gap-2 text-xs font-bold uppercase tracking-wider border transition-all ${paymentMethod === 'apple_pay' ? 'bg-white border-neutral-300 shadow-sm' : 'border-transparent text-neutral-400'}`}
                        >
                             Pay
                        </button>
                    </div>

                    <div className="space-y-4">
                        <div className="bg-white border border-[#E6EBF1] shadow-sm rounded-md overflow-hidden">
                            <div className="px-4 py-4 border-b border-[#F3F6F9]">
                                <label className="text-[10px] font-bold text-[#6B7C93] uppercase tracking-wider mb-2 block">Card Information</label>
                                <div className="flex items-center gap-4">
                                    <div className="flex-1">
                                        <input 
                                            name="number"
                                            value={cardDetails.number}
                                            onChange={handleCardChange}
                                            placeholder="Card number"
                                            className="w-full text-sm outline-none placeholder-[#CFD7DF]"
                                        />
                                    </div>
                                    <div className="w-10 flex justify-end">
                                        <CreditCard size={18} className="text-[#AAB7C4]" />
                                    </div>
                                </div>
                            </div>
                            <div className="flex border-b border-[#F3F6F9]">
                                <div className="flex-1 px-4 py-4 border-r border-[#F3F6F9]">
                                    <input 
                                        name="expiry"
                                        value={cardDetails.expiry}
                                        onChange={handleCardChange}
                                        placeholder="MM / YY"
                                        className="w-full text-sm outline-none placeholder-[#CFD7DF]"
                                    />
                                </div>
                                <div className="w-24 px-4 py-4">
                                    <input 
                                        name="cvc"
                                        value={cardDetails.cvc}
                                        onChange={handleCardChange}
                                        placeholder="CVC"
                                        className="w-full text-sm outline-none placeholder-[#CFD7DF]"
                                    />
                                </div>
                            </div>
                        </div>
                        <div className="bg-white border border-[#E6EBF1] shadow-sm rounded-md px-4 py-4">
                            <input 
                                name="zip"
                                value={cardDetails.zip}
                                onChange={handleCardChange}
                                placeholder="Postal code"
                                className="w-full text-sm outline-none placeholder-[#CFD7DF]"
                            />
                        </div>
                    </div>

                    <div className="pt-6">
                        <button 
                            onClick={handlePlaceOrder}
                            disabled={loading}
                            className={`w-full py-5 bg-[#6772E5] text-white text-[11px] font-bold uppercase tracking-[0.2em] shadow-lg hover:bg-[#5469D4] transition-all flex items-center justify-center gap-3 ${loading ? 'opacity-75' : ''}`}
                        >
                            {loading ? (
                                <>
                                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                                    Authorizing...
                                </>
                            ) : (
                                <>
                                    <Lock size={14} /> Complete Order • {CURRENCY}{total.toFixed(2)}
                                </>
                            )}
                        </button>
                        <p className="text-center text-[10px] text-[#6B7C93] mt-6 flex items-center justify-center gap-2 font-medium">
                            <Lock size={12} /> Encrypted, secure connection via Stripe gateway
                        </p>
                    </div>
                </div>
            </section>
        </div>

        {/* Right: Summary Sidebar */}
        <div className="lg:col-span-5">
            <aside className="bg-[#FAFAFA] border border-neutral-100 p-8 sticky top-32">
                <h3 className="font-serif text-2xl font-medium mb-10">Selection Summary</h3>
                
                <div className="space-y-8 mb-10 overflow-y-auto max-h-[40vh] pr-4 scrollbar-hide">
                    {cart.map((item, idx) => (
                        <div key={`${item.productId}-${idx}`} className="flex gap-6">
                            <div className="w-16 h-20 bg-white border border-neutral-100 p-2 flex-shrink-0">
                                <img src={item.image} alt={item.name} className="w-full h-full object-contain mix-blend-multiply" />
                            </div>
                            <div className="flex-1 py-1">
                                <h4 className="text-[13px] font-semibold text-black leading-tight mb-1">{item.name}</h4>
                                <div className="flex justify-between items-end">
                                    <span className="text-[11px] text-neutral-400 font-bold uppercase tracking-widest">Qty: {item.quantity}</span>
                                    <span className="text-sm font-medium">{CURRENCY}{(item.price * item.quantity).toFixed(2)}</span>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                <div className="space-y-4 pt-8 border-t border-neutral-200">
                    <div className="flex justify-between text-sm text-neutral-500">
                        <span>Subtotal</span>
                        <span>{CURRENCY}{subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm text-neutral-500">
                        <span>Shipping</span>
                        <span className={shipping === 0 ? 'text-green-600 font-bold' : ''}>{shipping === 0 ? 'COMPLIMENTARY' : `${CURRENCY}${shipping.toFixed(2)}`}</span>
                    </div>
                    <div className="flex justify-between text-sm text-neutral-500">
                        <span>Estimated Tax (VAT)</span>
                        <span>{CURRENCY}{tax.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-xl font-medium text-black pt-6 border-t border-neutral-200">
                        <span>Total Due</span>
                        <span style={{ color: config.primaryColor }}>{CURRENCY}{total.toFixed(2)}</span>
                    </div>
                </div>

                <div className="mt-10 bg-white border border-neutral-100 p-4 rounded text-[11px] leading-relaxed text-neutral-500 italic">
                    By completing this order, you confirm you are 21 years of age or older. Valid ID must be presented at the time of delivery.
                </div>
            </aside>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
