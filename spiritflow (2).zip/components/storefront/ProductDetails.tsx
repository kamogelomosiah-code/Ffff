import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useStore } from '../../context/StoreContext';
import { Plus, Check, ChevronRight, Truck, Box, Tag, ArrowUpRight } from '../common/Icons';
import { CURRENCY } from '../../constants';

const ProductDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { products, addToCart, cart, config } = useStore();
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);

  const product = products.find(p => p.id === Number(id));

  useEffect(() => {
    setQuantity(1);
    setAdded(false);
    window.scrollTo(0, 0);
  }, [id]);

  if (!product) return null;

  const relatedProducts = products
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  const handleAddToCart = () => {
    addToCart(product, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div className="bg-white pb-24 animate-in fade-in duration-500">
      <div className="max-w-7xl mx-auto px-6 py-12">
        {/* Gallery Style Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-start">
          
          {/* Product Image */}
          <div className="bg-[#FAFAFA] aspect-square flex items-center justify-center p-20 sticky top-32">
            <img 
              src={product.image} 
              alt={product.name} 
              className="w-full h-full object-contain mix-blend-multiply scale-110"
            />
          </div>

          {/* Product Specs */}
          <div className="py-10">
            <div className="mb-12">
              <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-neutral-400 block mb-4">{product.category}</span>
              <h1 className="font-serif text-5xl font-medium mb-6 leading-tight">{product.name}</h1>
              <div className="text-2xl font-medium mb-8" style={{ color: config.primaryColor }}>{CURRENCY}{product.price.toFixed(2)}</div>
              <p className="text-neutral-500 leading-relaxed text-lg max-w-lg mb-10">
                {product.description}
              </p>
            </div>

            <div className="space-y-6 mb-12 border-y border-neutral-100 py-10">
                <div className="flex justify-between items-center text-sm">
                    <span className="text-neutral-400 font-medium uppercase tracking-widest text-[11px]">Region / Origin</span>
                    <span className="font-semibold">Imported Excellence</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                    <span className="text-neutral-400 font-medium uppercase tracking-widest text-[11px]">Expression</span>
                    <span className="font-semibold">{product.subcategory || 'Signature'}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                    <span className="text-neutral-400 font-medium uppercase tracking-widest text-[11px]">Volume</span>
                    <span className="font-semibold">{product.volume}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                    <span className="text-neutral-400 font-medium uppercase tracking-widest text-[11px]">Strength</span>
                    <span className="font-semibold">{product.abv}% ABV</span>
                </div>
            </div>

            {/* Buying Block */}
            <div className="space-y-6">
                <div className="flex items-center gap-6">
                    <div className="flex items-center border border-neutral-200">
                      <button 
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                        className="w-14 h-14 flex items-center justify-center text-neutral-400 hover:text-black transition-colors"
                      >
                        -
                      </button>
                      <span className="w-8 text-center font-bold text-sm">{quantity}</span>
                      <button 
                        onClick={() => setQuantity(quantity + 1)}
                        className="w-14 h-14 flex items-center justify-center text-neutral-400 hover:text-black transition-colors"
                      >
                        +
                      </button>
                    </div>
                    
                    <button 
                      onClick={handleAddToCart}
                      className="flex-1 h-14 bg-black text-white text-[11px] font-bold uppercase tracking-widest hover:bg-neutral-800 transition-all active:scale-[0.98]"
                    >
                      {added ? 'In Your Selection' : 'Add to Collection'}
                    </button>
                </div>
                
                <div className="flex items-center justify-center gap-6 pt-4 text-[10px] font-bold uppercase tracking-widest text-neutral-400">
                    <span className="flex items-center gap-2"><Truck size={14} /> Free Express Shipping</span>
                    <span className="flex items-center gap-2"><Check size={14} /> Age Verified</span>
                </div>
            </div>
          </div>
        </div>

        {/* Suggestion Section */}
        <div className="mt-32 pt-24 border-t border-neutral-100">
          <div className="flex justify-between items-end mb-12">
            <h3 className="font-serif text-3xl font-medium">Further Discoveries</h3>
            <button onClick={() => navigate('/')} className="text-xs font-bold uppercase tracking-widest underline underline-offset-8">View All</button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12">
            {relatedProducts.map(rp => (
              <div 
                key={rp.id}
                onClick={() => navigate(`/product/${rp.id}`)}
                className="group cursor-pointer"
              >
                <div className="aspect-[3/4] bg-[#FAFAFA] flex items-center justify-center p-8 border border-neutral-100 transition-colors group-hover:bg-neutral-100 mb-6">
                   <img src={rp.image} alt={rp.name} className="w-full h-full object-contain mix-blend-multiply group-hover:scale-105 transition-transform duration-500" />
                </div>
                <h4 className="text-[13px] font-semibold mb-1 group-hover:underline underline-offset-4">{rp.name}</h4>
                <p className="text-[13px] text-neutral-400 font-medium">{CURRENCY}{rp.price.toFixed(2)}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetails;