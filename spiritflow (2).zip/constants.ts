import { Product, Order, StoreConfig, PrimaryColorPreset } from './types';

export const CURRENCY = 'R';

export const INITIAL_CONFIG: StoreConfig = {
  storeName: "SpiritFlow Liquors",
  primaryColor: PrimaryColorPreset.Navy,
  layout: 'grid',
  heroImage: "https://images.unsplash.com/photo-1569937756447-e24e5256e409?auto=format&fit=crop&q=80&w=2000",
  heroHeadline: "Premium Spirits Delivered",
  heroSubheadline: "From top shelf to your door in under 60 minutes.",
  contactEmail: "support@spiritflow.com",
  contactPhone: "(555) 123-4567"
};

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 1,
    name: "Heineken Premium Lager",
    category: "Beer",
    subcategory: "Lager",
    price: 24.99,
    stock: 150,
    sku: "BEER-001",
    image: "https://img.freepik.com/premium-vector/beer-bottle-flat-illustration-isolated-white-background_634443-417.jpg",
    description: "The world-famous premium lager in its iconic green bottle.",
    abv: 5.0,
    volume: "330ml",
    featured: true
  },
  {
    id: 2,
    name: "Finlandia Pure Vodka",
    category: "Spirits",
    subcategory: "Vodka",
    price: 189.99,
    stock: 45,
    sku: "SPR-002",
    image: "https://img.freepik.com/premium-vector/vodka-bottle-flat-illustration-isolated-white-background_634443-422.jpg",
    description: "Exceptionally smooth vodka made from pure glacial spring water.",
    abv: 40,
    volume: "750ml",
    featured: true
  },
  {
    id: 3,
    name: "Johnnie Walker Red Label",
    category: "Spirits",
    subcategory: "Whiskey",
    price: 245.50,
    stock: 30,
    sku: "SPR-003",
    image: "https://img.freepik.com/premium-vector/whiskey-bottle-flat-illustration-isolated-white-background_634443-419.jpg",
    description: "The world's best-selling Scotch Whisky, perfect for mixing.",
    abv: 40,
    volume: "750ml",
    featured: true
  },
  {
    id: 4,
    name: "Vintage Napa Cabernet",
    category: "Wine",
    subcategory: "Red",
    price: 450.00,
    stock: 12,
    sku: "WINE-004",
    image: "https://img.freepik.com/premium-vector/wine-bottle-flat-illustration-isolated-white-background_634443-415.jpg",
    description: "A full-bodied red with deep notes of black cherry and oak.",
    abv: 14.5,
    volume: "750ml",
    featured: true
  },
  {
    id: 5,
    name: "Silver Agave Tequila",
    category: "Spirits",
    subcategory: "Tequila",
    price: 320.00,
    stock: 20,
    sku: "SPR-005",
    image: "https://img.freepik.com/premium-vector/tequila-bottle-flat-illustration-isolated-white-background_634443-421.jpg",
    description: "Crisp and vibrant tequila distilled from 100% blue agave.",
    abv: 38,
    volume: "750ml",
    featured: false
  }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: "ORD-1001",
    customerName: "Alex Johnson",
    customerEmail: "alex@example.com",
    customerPhone: "(555) 987-6543",
    date: "2023-10-25T14:30:00",
    status: "pending",
    total: 214.98,
    deliveryAddress: "123 Maple Ave, Apt 4B",
    items: [
      { 
        productId: 1, 
        name: "Heineken Premium Lager", 
        price: 24.99, 
        quantity: 1, 
        image: "https://img.freepik.com/premium-vector/beer-bottle-flat-illustration-isolated-white-background_634443-417.jpg" 
      },
      { 
        productId: 2, 
        name: "Finlandia Pure Vodka", 
        price: 189.99, 
        quantity: 1, 
        image: "https://img.freepik.com/premium-vector/vodka-bottle-flat-illustration-isolated-white-background_634443-422.jpg" 
      }
    ]
  }
];